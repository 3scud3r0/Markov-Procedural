# narrativa

Um jardineiro de estrelas chegou a uma estação abandonada. Encontrou uma semente luminosa e decidiu plantar uma memória. A viagem estava apenas começando.
